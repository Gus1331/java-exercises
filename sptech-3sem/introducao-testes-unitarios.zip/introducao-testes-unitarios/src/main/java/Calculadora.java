public class Calculadora {

    public Double somar(Double n1, Double n2){
        if(n1 == null || n2 == null){
            throw new IllegalArgumentException("Achei paia");
        }
        return n1 + n2;
    }
}
